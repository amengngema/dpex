            
    <footer class="main">
	    <div class="container">
	        <p><a href="<?php echo site_url(); ?>">DPEX Worldwide</a> © 2017 All rights reserved</p>
	    </div>
	</footer>

	<?php wp_footer(); // js scripts are inserted using this function ?>

</body>

</html>
